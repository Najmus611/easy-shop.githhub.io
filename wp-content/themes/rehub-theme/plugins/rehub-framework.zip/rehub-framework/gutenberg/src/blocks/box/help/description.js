const {__} = wp.i18n;
export default  __('Colored Info Boxes', 'rehub-framework');
