export default 'info';

